INSERT INTO Subject (SubjectID,SubjectName,Rating) VALUES (1, 'Linux',4.0);
INSERT INTO Subject (SubjectID,SubjectName,Rating) VALUES (2, 'Azure DevOps',4.0);
INSERT INTO Subject (SubjectID,SubjectName,Rating) VALUES (3, 'Python',4.0);